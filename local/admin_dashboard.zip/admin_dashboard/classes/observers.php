<?php
namespace local_admin_dashboard;
defined('MOODLE_INTERNAL') || die();

class observers
{
    public static function dashboard(\core\event\dashboard_viewed $event){
        global $CFG;
        if (empty($event)) 
        {
            return;
        }
        else
        {
            $url = $CFG->wwwroot . '/local/admin_dashboard/';
            if (is_siteadmin()) {
                echo '<script> 
                window.location.replace("'.$url.'");
                </script>';
            }
        }
    }
}