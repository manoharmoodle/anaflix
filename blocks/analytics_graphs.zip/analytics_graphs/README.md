AnalyticsGraphs
===============

Learning analytics Moodle plugin - graphs to help teachers.
